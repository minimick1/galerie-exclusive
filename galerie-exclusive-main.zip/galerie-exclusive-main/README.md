TUTORIEL POUR METTRE EN LIGNE SUR GITHUB PAGES

1. Créez un compte sur https://github.com
2. Créez un repository public (ex: galerie-exclusive).
3. Ajoutez ces fichiers :
   - index.html
   - style.css
   - dossier images (avec apercu.jpg, photo1.jpg...)
4. Allez dans Settings > Pages > activez "Deploy from branch".
5. Votre site sera accessible ici :
   https://votre-nom.github.io/galerie-exclusive/

POUR LE FORMULAIRE:
- Remplacez "https://formspree.io/f/votre-code-unique" par le lien Formspree.
- Inscrivez-vous sur https://formspree.io/ pour recevoir les messages par email.
